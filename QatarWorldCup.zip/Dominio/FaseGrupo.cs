﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class FaseGrupo : Partido
    {
        private string grupo;
        public const string Fase = "Fase de Grupos";

        public string Grupo
        {
            get { return grupo; }
            set { grupo = value; }
        }

        public FaseGrupo(int id, string grupo, Seleccion seleccion1, Seleccion seleccion2, DateTime fechaHora, List<Incidencia> incidencias) : base(id, seleccion1, seleccion2, fechaHora, incidencias)
        {            
            this.Grupo = grupo;
        }

        public override string ObtenerFase()
        {
            return Fase;
        }

        public override string ObtenerEtapa()
        {
            return this.grupo;
        }

        public override void ValidarResultado()
        {
            if (this.Resultado1 > this.Resultado2)
            {
                this.Resultado = "Ganador: " + this.Seleccion1.Pais.Nombre;
            }
            else if (this.Resultado1 < this.Resultado2)
            {
                this.Resultado = "Ganador: " + this.Seleccion2.Pais.Nombre;
            }
            else
            {
                this.Resultado = "Empate.";
            }
        }
        
        public override void FinalizarPartido()
        {
            if (Finalizado == false)
            {                
                this.Resultado1 = ObtenerGolesPorSeleccion(this.Seleccion1);
                this.Resultado2 = ObtenerGolesPorSeleccion(this.Seleccion2);
                ValidarResultado();
                Finalizado = true;
            }
            else
            {
                throw new Exception("El partido ya está finalizado.");
            }
        }
    }
}
