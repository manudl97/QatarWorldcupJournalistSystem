﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class FaseEliminatoria : Partido
    {
        private bool alargue;
        private bool penales;
        private string etapa;
        public const string Fase = "Fase Eliminatoria";


        public bool Alargue
        {
            get { return alargue; }
            set { alargue = value; }
        }

        public bool Penales
        {
            get { return penales; }
            set { penales = value; }
        }

        public string Etapa
        {
            get { return etapa; }
            set { etapa = value; }
        }

        public FaseEliminatoria(int id, bool alargue, bool penales, string etapa, Seleccion seleccion1, Seleccion seleccion2, DateTime fechaHora, List<Incidencia> incidencias) : base(id, seleccion1, seleccion2, fechaHora, incidencias)
        {
            this.Alargue = alargue;
            this.Penales = penales;
            this.Etapa = etapa;
        }

        public override string ObtenerFase()
        {
            return Fase;
        }

        public override string ObtenerEtapa()
        {
            return this.Etapa;
        }

        public override void ValidarResultado()
        {
            if (this.Penales)
            {
                this.Resultado = "Empate. | ";
                if (this.Resultado1 > this.Resultado2)
                {
                    this.Resultado += "Ganador: " + this.Seleccion1.Pais.Nombre + " por penales.";
                }
                else if (this.Resultado1 < this.Resultado2)
                {
                    this.Resultado += "Ganador: " + this.Seleccion2.Pais.Nombre + " por penales.";
                }
            }
            else
            {
                if (this.Resultado1 > this.Resultado2)
                {
                    this.Resultado = "Ganador: " + this.Seleccion1.Pais.Nombre;
                }
                else if (this.Resultado1 < this.Resultado2)
                {
                    this.Resultado = "Ganador: " + this.Seleccion2.Pais.Nombre;
                }
                else
                {
                    this.Resultado = ". | En alargue de juego.";
                }
            }
        }

        public override void FinalizarPartido()
        {
            if (Finalizado == false)
            {
                this.Resultado1 = ObtenerGolesPorSeleccion(this.Seleccion1);
                this.Resultado2 = ObtenerGolesPorSeleccion(this.Seleccion2);
                ValidarResultado();
                Finalizado = true;
            }
            else
            {
                throw new Exception("El partido ya está finalizado.");
            }
        }
    }
}
