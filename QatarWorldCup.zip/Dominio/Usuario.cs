﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Usuario //→ Explicación en grabación 09-11-2022 34:10min de por qué no es abstracto | El model binging no soporta
    {
        private string nombre;
        private string apellido;
        private string username;
        private string email;
        private string password;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }
        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
                
        public Usuario(string nombre, string apellido, string username, string email, string password)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Username = username;
            this.Email = email;
            this.Password = password;
        }
        public Usuario()
        {
            this.Nombre = "Sin definir";
            this.Apellido = "Sin definir";
            this.Username = "Desconocido";
            this.Email = "***@***";
            this.Password = "000";
        }

        public virtual string ObtenerRol()
        {
            return "SIN_ROL";
        }


    }

}

