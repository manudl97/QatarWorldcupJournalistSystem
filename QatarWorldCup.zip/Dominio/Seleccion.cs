﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Seleccion:IValidar, IComparable
    {

        private Pais pais;
        private List<Jugador> jugadores;

        public Pais Pais
        {
            get { return pais; }
            set { pais = value; }
        }

        public List<Jugador> Jugadores
        {
            get { return jugadores; }
            set { jugadores = value; }
        }

        public override string ToString()
        {
            string listaJugadores = "";
            int indice = 0; //posición del jugador dentro de la lista
            foreach (Jugador j in Jugadores)
            {
                indice++;
                listaJugadores += indice.ToString() + " " + j + "\n";
            }
            return Pais + ": \n";
        }
       
        public Seleccion(Pais pais)
        {
            this.Pais = pais;
            Jugadores = new List<Jugador>(); 
        }

        public void AgregarJugador(Jugador j) 
        {
            Jugadores.Add(j);
        }

        public void Validar()
        {
            int contador = 0;
            foreach(Jugador j in Jugadores)
            {
                contador++;                
            }
            if (contador < 11)
            {
                throw new Exception("La lista de jugadores por selección no debe contener más de 11 jugadores.");
            }

        }
                

        public int CompareTo(Object obj)
        {
            Seleccion seleccion = (Seleccion)obj;
            return this.Pais.Nombre.CompareTo(seleccion.Pais.Nombre);
        }
    }
}
