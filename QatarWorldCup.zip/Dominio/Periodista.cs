﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Periodista : Usuario, IValidar, IComparable
    {
        public static int contador = 1;
        public int ID { get; set; }
        public const string Rol = "Periodista";

        public Periodista(string nombre, string apellido, string username, string email, string password) : base(nombre, apellido, username, email, password)
        {
            this.ID = contador++;
        }

        public Periodista()
        {
            this.ID = contador++;
        }

        public override string ToString()
        {
            return $"Nombre: {Nombre}" + $"Apellido: {Apellido}" + "\n" + $"Email: {Email}";
        }

        public void Validar()
        {
            if (this.Nombre != null && this.Apellido != null && this.Username != null && this.Email != null && this.Password != null)
            {
                ValidarEmail();
                ValidarPassword();
            }
            else
            {
                throw new Exception("Todos los campos deben ser completados sin errores");
            }
        }

        public void ValidarEmail()
        {
            if (!this.Email.Contains("@") || this.Email.StartsWith("@") || this.Email.EndsWith("@"))
            {
                throw new Exception("Debe ingresar un correo electronico correcto. Debe contener @ y no debe estar ni al principio ni al final");
            }
        }

        public void ValidarPassword()
        {
            if (this.Password.Length < 8)
            {
                throw new Exception("La contrasena debe tener al menos 8 caracteres, por favor intente nuevamente");
            }
        }

        public override string ObtenerRol()
        {
            return Rol;
        }

        public int CompareTo(Object obj)
        {
            Periodista periodista = (Periodista)obj;
            int resultado = this.Apellido.CompareTo(periodista.Apellido);
            if (resultado == 0)
            {
                resultado = this.Nombre.CompareTo(periodista.Nombre);
            }
            return resultado;
        }
    }
}
