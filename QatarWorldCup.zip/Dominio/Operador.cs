﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Operador: Usuario
    {
        private DateTime fechaInicio;
        public const string Rol = "Operador";

        public DateTime FechaInicio
        {
            get { return fechaInicio; }
            set { fechaInicio = value; }
        }    

        public Operador(string nombre, string apellido, string username, string email, string password, DateTime fechaInicio) : base(nombre, apellido, username, email, password)
        {
            this.FechaInicio = fechaInicio;
        }

        public Operador() { }

        public override string ObtenerRol()
        {
            return Rol;
        }
    }
}
