﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Jugador : IValidar, IComparable
    {
        private int id;
        private string nroCamiseta;
        private string nombreCompleto;
        private DateTime fechaNacimiento;
        private double altura; 
        private string pieHabil;
        private int valorMercado; 
        private string moneda;
        private Pais pais;
        private string posicion;
        private static int montoReferencia;
        private string categoriaFinanciera;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string NroCamiseta
        {
            get { return nroCamiseta; }
            set { nroCamiseta = value; }
        }

        public string NombreCompleto
        {
            get { return nombreCompleto; }
            set { nombreCompleto = value; }
        }

        public DateTime FechaNacimiento
        {
            get { return fechaNacimiento; }
            set { fechaNacimiento = value; }
        }

        public double Altura
        {
            get { return altura; }
            set { altura = value; }
        }

        public string PieHabil
        {
            get { return pieHabil; }
            set { pieHabil = value; }
        }

        public int ValorMercado
        {
            get { return valorMercado; }
            set { valorMercado = value; }
        }

        public string Posicion
        {
            get { return posicion; }
            set { posicion = value; }
        }

        public static int MontoReferencia
        {
            get { return montoReferencia; }
            set { montoReferencia = value; }
        }

        public string CategoriaFinanciera
        {
            get { return categoriaFinanciera; }
            set { categoriaFinanciera = value; }
        }

        public string Moneda
        {
            get { return moneda; }
            set { moneda = value; }
        }

        public Pais Pais
        {
            get { return pais; }
            set { pais = value; }
        }

        public override string ToString()
        {
            return "Nombre Jugador: " + NombreCompleto + "|| Valor de Mercado: " + ValorMercado + "|| Categoria: " + DeterminarCategoriaFinanciera().ToString();
        }

        public Jugador(int id, string nroCamiseta, string nombreCompleto, DateTime fechaNacimiento, double altura, string pieHabil, int valorMercado, string moneda, Pais pais, string posicion)
        {
            this.Id = id;
            this.NroCamiseta = nroCamiseta;
            this.NombreCompleto = nombreCompleto;
            this.FechaNacimiento = fechaNacimiento;
            this.Altura = altura;
            this.PieHabil = pieHabil;
            this.ValorMercado = valorMercado;
            this.Moneda = moneda;
            this.Pais = pais;
            this.Posicion = posicion;
            this.CategoriaFinanciera = DeterminarCategoriaFinanciera();
        }

        public void Validar() //Hay tres jugadores de la precarga que contienen errores en algunos campos, estos se reflejan en las tres primeras lineas en consola → Optamos por dejarlo para validar que este método funciona.
        {
            if (this.id < 0 || this.NombreCompleto == null || this.nroCamiseta == null || this.fechaNacimiento == null || this.altura < 0 || this.pieHabil == null || this.valorMercado <= 0 || this.moneda == null || this.pais == null || this.posicion == null)
            {
                throw new Exception("Los datos del jugador no son correctos.");
            }
        }

        public string DeterminarCategoriaFinanciera() //→ Asigna categoria según valor de mercado del jugador
        {
            if (ValorMercado > MontoReferencia)
            {
                CategoriaFinanciera = "VIP";
            }
            else
            {
                CategoriaFinanciera = "Estandar";
            }
            return CategoriaFinanciera;
        }

        public void VerificarVMercado()
        {
            if (MontoReferencia < 0)
            {
                throw new Exception("El valor de referencia debe ser mayor a 0. Reintentar");
            }
        }

        public static void AsignarMontoReferencia(int pMonto)
        {
            MontoReferencia = pMonto;
        }

        public int CompareTo(Object obj)
        {
            Jugador j = (Jugador)obj;
            int resultado = j.ValorMercado.CompareTo(this.ValorMercado);
            if (resultado == 0)
            {
                resultado = j.NombreCompleto.CompareTo(this.NombreCompleto);
            }
            return resultado;
        }
    }
}
