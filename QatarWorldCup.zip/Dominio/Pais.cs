﻿using System;

namespace Dominio
{
    public class Pais:IValidar
    {

        private int id;
        private string nombre;
        private string codigoAlpha;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string CodigoAlpha
        {
            get { return codigoAlpha; }
            set { codigoAlpha = value; }
        }

        public override string ToString()
        {
            return "" + Nombre + " " + CodigoAlpha;
        }

        public Pais ( string nombre, string codigoAlpha)
        {
            this.Nombre = nombre;
            this.CodigoAlpha = codigoAlpha;
        }

        public void Validar()
        {
            if (Sistema.ValidarNotNull(Nombre.ToString()))
            {
                ValidarCodigoAlpha();
            }
        }

        public void ValidarCodigoAlpha()
        {
            if (CodigoAlpha.Length != 3)
            {
                Console.WriteLine("El Codigo Alpha3 es incorrecto.");
            }
        }
    }
}
