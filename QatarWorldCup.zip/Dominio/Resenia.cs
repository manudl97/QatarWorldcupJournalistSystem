﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Resenia : IComparable
    {
        private Periodista periodista;
        private DateTime fecha;
        private Partido partido;
        private string titulo;
        private string contenido;
        private int idPartido;


        public Periodista Periodista
        {
            get { return periodista; }
            set { periodista = value; }
        }


        public DateTime Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }


        public Partido Partido
        {
            get { return partido; }
            set { partido = value; }
        }


        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }

        public string Contenido
        {
            get { return contenido; }
            set { contenido = value; }
        }
        public int IdPartido
        {
            get { return idPartido; }
            set { idPartido = value; }
        }

        public Resenia(Periodista periodista, DateTime fecha, Partido partido, string titulo, string contenido)
        {
            this.Periodista = periodista;
            this.Fecha = fecha;
            this.Partido = partido;
            this.Titulo = titulo;
            this.Contenido = contenido;

        }
        public Resenia() { }

        public int CompareTo(object obj)
        {
            Resenia resenia = (Resenia)obj;
            return this.Fecha.CompareTo(resenia.Fecha);
        }
    }

    
}
        

