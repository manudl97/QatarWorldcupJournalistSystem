﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Partido : IValidar
    {
        private int id;
        private Seleccion seleccion1;
        private Seleccion seleccion2;
        private DateTime fechaHora;
        private bool finalizado;
        private List<Incidencia> incidencias;
        private string resultado;
        private int resultado1;
        private int resultado2;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public Seleccion Seleccion1
        {
            get { return seleccion1; }
            set { seleccion1 = value; }
        }

        public Seleccion Seleccion2
        {
            get { return seleccion2; }
            set { seleccion2 = value; }
        }

        public DateTime FechaHora
        {
            get { return fechaHora; }
            set { fechaHora = value; }
        }

        public bool Finalizado
        {
            get { return finalizado; }
            set { finalizado = value; }
        }

        public List<Incidencia> Incidencias
        {
            get { return incidencias; }
            set { incidencias = value; }
        }

        public string Resultado
        {
            get { return resultado; }
            set { resultado = value; }
        }

        public int Resultado1
        {
            get { return resultado1; }
            set { resultado1 = value; }
        }

        public int Resultado2
        {
            get { return resultado2; }
            set { resultado2 = value; }
        }

        public override string ToString()
        {
            return "Fecha y hora: " + FechaHora + "Partido: " + Seleccion1.Pais.Nombre + " vs " + Seleccion2.Pais.Nombre + "\n" + "Cantidad de incidencias: " + Incidencias.Count;
        }


        public Partido(int id, Seleccion seleccion1, Seleccion seleccion2, DateTime fechaHora, List<Incidencia> incidencias)
        {
            this.Id = id;
            this.Seleccion1 = seleccion1;
            this.Seleccion2 = seleccion2;
            this.FechaHora = fechaHora;
            this.Finalizado = false;
            this.Incidencias = incidencias; 
        }

        public Partido()
        {
        }

        public void Validar()
        {
            if (Sistema.ValidarNotNull(Seleccion1.ToString()) && Sistema.ValidarNotNull(Seleccion2.ToString()) && Seleccion1 != Seleccion2)
            {
                ValidarFecha();
            }
        }

        public void ValidarFecha()
        {
            DateTime fechaInicio = new DateTime(2022, 11, 20);
            DateTime fechaFinal = new DateTime(2022, 12, 18);
            if (this.fechaHora < fechaInicio || this.fechaHora > fechaFinal)
            {
                throw new Exception("Los partidos deben estar comprendidos entre el 20/11/2022 y 18/12/2022");
            }
        }
        public virtual string ObtenerFase()
        {
            return "SIN_FASE";
        }

        public virtual string ObtenerEtapa()
        {
            return "SIN_ETAPA";
        }       

        public virtual int ObtenerGolesPorSeleccion(Seleccion seleccion)
        {
            int goles = 0;            
            foreach (Incidencia i in Incidencias)
            {
                if (i.Jugador.Pais.Nombre.Equals(seleccion.Pais.Nombre) && i.TipoIncidencia == TipoIncidencia.Gol) 
                {
                    goles++;
                }
            }            
            return goles;            
        }
              

        public virtual int ObtenerAmonestacionPorSeleccion(Seleccion seleccion)
        {
            int amonestaciones = 0;
            foreach (Incidencia i in Incidencias)
            {
                if (i.Jugador.Pais.Nombre.Equals(seleccion.Pais.Nombre) && i.TipoIncidencia == TipoIncidencia.Amonestado)
                {
                    amonestaciones++;
                }
            }
            return amonestaciones;
        }

        public virtual int ObtenerExpulsionPorSeleccion(Seleccion seleccion)
        {
            int expulsiones = 0;
            foreach (Incidencia i in Incidencias)
            {
                if (i.Jugador.Pais.Nombre.Equals(seleccion.Pais.Nombre) && i.TipoIncidencia == TipoIncidencia.Expulsado)
                {
                    expulsiones++;
                }
            }
            return expulsiones;
        }    

        public virtual void ValidarResultado() { }

        public virtual void FinalizarPartido() { }
    }
}
