﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class Incidencia : IValidar
    {
        private Jugador jugador;
        private int minuto;
        private TipoIncidencia tipoIncidencia;

        public Jugador Jugador
        {
            get { return jugador; }
            set { jugador = value; }
        }

        public int Minuto
        {
            get { return minuto; }
            set { minuto = value; }
        }

        public TipoIncidencia TipoIncidencia
        {
            get { return tipoIncidencia; }
            set { tipoIncidencia = value; }
        }

        public override string ToString()
        {
            return Jugador + " " + Minuto + " " + TipoIncidencia;
        }

        public Incidencia(Jugador jugador, int minuto, TipoIncidencia tipoIncidencia)
        {
            this.Jugador = jugador;
            this.Minuto = minuto;
            this.TipoIncidencia = tipoIncidencia;
        }        

        public void Validar()
        {
            if (!Sistema.ValidarNotNull(Jugador.ToString()) && !Sistema.ValidarNotNull(Minuto.ToString()) && !Sistema.ValidarNotNull(TipoIncidencia.ToString()))
            {
                throw new Exception("Los campos no deben estar vacíos.");
            }
        }           
    }
}
