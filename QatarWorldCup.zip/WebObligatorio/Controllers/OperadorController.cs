﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class OperadorController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;
        public IActionResult Index()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                string userLogueado = HttpContext.Session.GetString("UsuarioLogueado"); //Obtengo el nombre del usuario de la sesión            
                Usuario usuario = sistema.ObtenerUsuarioPorUsername(userLogueado); //Obtengo Usuario como objeto completo           
                return View(usuario);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MenuPartido()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MenuPeriodista()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MenuEstadisticas()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MostrarPeriodistas()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                List<Periodista> periodistas = sistema.ListarPeriodistas();
                return View(periodistas);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        
    }
}
