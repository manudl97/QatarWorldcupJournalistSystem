﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class PartidoController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;
        
        public IActionResult MostrarPartidos()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                List<Partido> partidos = sistema.ListarPartidos();

                return View(partidos);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }
       
        public IActionResult MostrarPartidosSinFinalizar()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                if (sistema.ListarPartidosSinFinalizar().Count > 0)
                {
                    {
                        List<Partido> partidos = sistema.ListarPartidosSinFinalizar();
                        return View(partidos);
                    }
                }
                else
                {
                    ViewBag.error = ("No hay partidos pendientes.");
                    return View();
                }
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        
        public IActionResult FinalizarPartidoGrupo(int idPartido)
        {
            try
            {
                sistema.ConcluirPartido(idPartido);
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
            }
            return RedirectToAction("MostrarPartidosSinFinalizar", "Partido");
        }

        
        public IActionResult FinalizarPartidoEliminatoria(int idPartido)
        {
            try
            {
                sistema.ConcluirPartido(idPartido);
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
            }
            return RedirectToAction("MostrarPartidosSinFinalizar", "Partido");
        }
        
        public IActionResult MostrarPartidosFinalizados()
        {            
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            ViewBag.Rol = rol;
            if (rol != null)
            {
                if (sistema.ListarPartidosFinalizados().Count > 0)
                {

                    List<Partido> partidos = sistema.ListarPartidosFinalizados();
                    return View(partidos);
                }
                else
                {
                    ViewBag.error = ("Aún no hay partidos finalizados.");
                    return View();
                }
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }
        
        public IActionResult BuscarPartidosEntreDosFechas()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }
        
        public IActionResult MostrarPartidosEntreDosFechas(DateTime f1, DateTime f2)
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            ViewBag.Rol = rol;
            if (rol != null && rol.Equals(Operador.Rol))
            {
                if (sistema.ObtenerPartidosEntreFechas(f1, f2).Count > 0)
                {
                    {
                        List<Partido> partidos = sistema.ObtenerPartidosEntreFechas(f1, f2);
                        return View(partidos);
                    }
                }
                else
                {
                    ViewBag.error = ("No hay partidos comprendidos entre estas fechas.");
                    return View();
                }
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }
                
        public IActionResult BuscarPartidosEmailPeriodista()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MostrarPartidosEmailPeriodista(string email)
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                if (sistema.ObtenerPartidoRojaEmailPeriodista(email).Count > 0)
                {
                    List<Partido> partidos = sistema.ObtenerPartidoRojaEmailPeriodista(email);
                    return View(partidos);
                }
                else
                {
                    ViewBag.error = ("No hay partidos con explusiones reseñados por este periodista.");
                    return View();
                }
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MostrarDetallesIncidencias(int idPartido)
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Operador.Rol))
            {
                List<Incidencia> incidencias = sistema.ObtenerDatosDeIncidencia(idPartido);
                return View(incidencias);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");

        }
    }
}
