﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class ReseniaController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;

        public IActionResult ListarResenias(string email)
        {
            string userEmail = HttpContext.Session.GetString("UsuarioLogueadoEmail");
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Periodista.Rol))
            {
                List<Resenia> resenias = sistema.ObtenerReseniaPorPeriodista(userEmail);
                return View(resenias);
            }
            else if (rol != null && rol.Equals(Operador.Rol))
            {
                List<Resenia> resenias = sistema.ObtenerReseniaPorPeriodista(email);
                return View(resenias);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult AltaResenia(int idPartido)
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Periodista.Rol))
            {
                ViewBag.idPartido = idPartido;
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        [HttpPost]
        public IActionResult AltaResenia(Resenia resenia)
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null && rol.Equals(Periodista.Rol))
            {
                sistema.AsociarPeriodistaResenia(HttpContext.Session.GetString("UsuarioLogueadoEmail"), resenia);
                sistema.AsociarPartidoYResenia(resenia);
                sistema.AltaResenia(resenia);
                return RedirectToAction("ListarResenias", "Resenia");
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }
    }
}
