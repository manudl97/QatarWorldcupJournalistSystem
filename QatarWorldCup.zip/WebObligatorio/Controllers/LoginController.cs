﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class LoginController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;
        public IActionResult UserLogin()
        {
            HttpContext.Session.Remove("UsuarioLogueado");
            HttpContext.Session.Remove("UsuarioLogueadoNombre");
            HttpContext.Session.Remove("UsuarioLogueadoEmail");
            HttpContext.Session.Remove("UsuarioLogueadoRol");
            return View();
        }

        [HttpPost]
        public IActionResult UserLogin(Usuario usuario)
        {
            try
            {
                sistema.Login(usuario);
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
                return View();
            }
            Usuario usuarioDeSistema = sistema.ObtenerUsuarioPorUsername(usuario.Username);
            HttpContext.Session.SetString("UsuarioLogueado", usuarioDeSistema.Username);          
            HttpContext.Session.SetString("UsuarioLogueadoNombre", usuarioDeSistema.Nombre);
            HttpContext.Session.SetString("UsuarioLogueadoEmail", usuarioDeSistema.Email);
            HttpContext.Session.SetString("UsuarioLogueadoRol", usuarioDeSistema.ObtenerRol());            

            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null)
            {
                if (rol.Equals(Operador.Rol))
                {
                    return RedirectToAction("Index", "Operador");
                }
                return RedirectToAction("Index", "Periodista");
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        
    }
}
