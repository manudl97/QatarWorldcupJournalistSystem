﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class PeriodistaController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;
        public IActionResult Index()
        {
            string userLogueado = HttpContext.Session.GetString("UsuarioLogueado"); //Obtengo el nombre del usuario de la sesión            
            Usuario usuario = sistema.ObtenerUsuarioPorUsername(userLogueado); //Obtengo Usuario como objeto completo 
            return View(usuario);
        }
    }        
}
