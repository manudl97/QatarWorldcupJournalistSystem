﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class UnknowUserController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult RegistroPeriodista()
        {
            return View();
        }                       

        [HttpPost]
        public IActionResult RegistroPeriodista(Periodista _periodista)
        {
            try
            {
                sistema.AltaPeriodista(_periodista);
            }
            catch (Exception e)
            {
                ViewBag.error = e.Message;
                return View();
            }
            return RedirectToAction("UserLogin", "Login");
        }
    }
}
