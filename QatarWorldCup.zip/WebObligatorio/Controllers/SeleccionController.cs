﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebObligatorio.Controllers
{
    public class SeleccionController : Controller
    {
        public Sistema sistema = Sistema.ObtenerInstancia;
        public IActionResult Index()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol == null || rol.Equals(Operador.Rol))
            {
                return View();
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MostrarSelecciones()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol == null || rol.Equals(Operador.Rol))
            {
                List<Seleccion> seleccion = sistema.ListarSelecciones();
                return View(seleccion);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult JugadorPorPais(string pais)
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol == null || rol.Equals(Operador.Rol))
            {
                List<Jugador> jugadores = sistema.ObtenerJugadorPorPais(pais);
                return View(jugadores);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }

        public IActionResult MostrarSeleccionGoleadora()
        {
            string rol = HttpContext.Session.GetString("UsuarioLogueadoRol");
            if (rol != null || rol.Equals(Operador.Rol))
            {
                ViewBag.Goles = sistema.ObtenerCantidadGoles();
                List<Seleccion> selecciones = sistema.ObtenerSeleccionConMasGoles();
                return View(selecciones);
            }
            TempData["mensajeError"] = "No tienes permisos para acceder a esta página.";
            return RedirectToAction("MostrarError", "Error");
        }
    }
}
