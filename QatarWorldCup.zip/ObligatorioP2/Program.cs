﻿using System;
using Dominio;

namespace ObligatorioP2
{
     class Program
    {
        static void Main(string[] args)
        {
            bool salir = false;

            
            Sistema sistema = Sistema.ObtenerInstancia; //Acá se obtiene la clase Sistema y la guardo en la variable sistema → Parte del método singleton
            
            while (!salir)
            {
                Console.WriteLine("\n\n##Obligatorio Programación 2## \n");
                Console.WriteLine("Seleccione una opción \n");
                Console.WriteLine("1 - Dar de alta periodista");
                Console.WriteLine("2 - Ingresar valor para asignar categoría financiera de los jugadores");
                Console.WriteLine("3 - Ingresar ID de jugador para conocer partidos en los que participó");
                Console.WriteLine("4 - Lista de jugadores expulsados");
                Console.WriteLine("5 - Ingresar nombre de Selección para conocer el partido con más goles");
                Console.WriteLine("6 - Ver lista de jugadores que hayan convertido un gol");
                Console.WriteLine("0 - Salir");

                bool error = int.TryParse(Console.ReadLine(), out int opcion); //Se crea en el caso de que el usuario ingrese una letra

                if (!error)
                {
                    Console.WriteLine("Error. Ingrese una opción valida");
                }
                else
                {
                    switch (opcion)
                    {
                        case 1:
                            sistema.CrearPeriodista();  
                            Console.WriteLine("\n \n \n");
                            break;
                        case 2:
                            sistema.AsignarValorFinancieroAJugador();
                            Console.WriteLine("\n \n \n");
                            break;
                        case 3:
                            sistema.ListarPartidosPorJugador();
                            Console.WriteLine("\n \n \n");
                            break;
                        case 4:
                            sistema.ListarJugadoresExpulsados(); //Recorre lista de incidencias
                            Console.WriteLine("\n \n \n");
                            break;
                        case 5:
                            sistema.MayorCantidadDeGolesSegunSeleccion();
                            Console.WriteLine("\n \n \n");
                            break;
                        case 6:
                            sistema.ListarJugadoresConGol();
                            Console.WriteLine("\n \n \n");
                            break;
                        case 0:
                            Console.WriteLine("Saliendo del sistema...");
                            salir = true;
                            break;
                        default:
                            Console.WriteLine("Opción fuera de rango. Ingrese una opción valida.");
                            break;
                    }
                }
            }
        }   
     }
}
